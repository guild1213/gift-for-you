//
//  TableViewD30C.swift
//  GIFT
//
//  Created by 朝倉健登 on 2021/12/05.
//

import UIKit
import SafariServices
 
class TableViewD30C: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-30-c-1-1",
            "d-30-c-2-1","d-30-c-3-1",
            "d-30-c-4-1","d-30-c-5-1",
            "d-30-c-6-1","d-30-c-7-1",
            "d-30-c-8-1","d-30-c-9-1"
            ,"d-30-c-10-1"
]
        
        let img1Array: NSArray = [
            "d-30-c-1-2",
            "d-30-c-2-2","d-30-c-3-2",
            "d-30-c-4-2","d-30-c-5-2",
            "d-30-c-6-2","d-30-c-7-2",
            "d-30-c-8-2","d-30-c-9-2",
            "d-30-c-10-2",]
        
        let img2Array: NSArray = [
            "d-30-c-1-3",
            "d-30-c-2-3","d-30-c-3-3",
            "d-30-c-4-3","d-30-c-5-3",
            "d-30-c-6-3","d-30-c-7-3",
            "d-30-c-8-3",
            "d-30-c-9-3","d-30-c-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "GANZO:THIN BRIDLE]\nパーツひとつずつにコバ磨きを施した繊細なつくり名刺が折れずにタップリ収納できる、通しマチ仕様で、口開きも良く、名刺がタップリ収納できる機能性も備えている。",
                        "[UNION ROYAL:PRESTIGE]\nミリ単位で長さや厚みなどバランスをミリ単位で調整し、とてもスマートで今日的なシルエットに仕上がっています。足なりの立体的な木型設計になっています。",
                        "[BRAUN:シリーズ9]\n改良されたプロブレードで長く伸びた寝たヒゲをより効果的に捕らえることを可能にしました。ブラウン独自の音波振動テクノロジーで肌との摩擦を軽減し一度で剃り切ります。",
                        "[BVLGARI:キーホルダー]\nブラックのブライトグレインカーフレザーとブラックナッパ製スモールキーホルダーにブラックナッパの裏地。ライトゴールドプレート金具で高級感があります。",
                        
                        "[TOMMY HILFIGER:ウールミックスコート]\nウール混紡率を高めた上品で暖かなスタンドカラーコート。スーツにも合わせやすいように、襟の高さから肩幅、着丈までしっかりと計算して仕立てられています。",
                        "[Johnstons:ストール マフラー]\nシンプルで洗練されたデザインでトレンドに左右されず、永くご愛用いただける1枚です。カシミヤ100％ならではの暖かさや滑らかな風合いが魅力です。",
                        "[Whitehouse Cox:S1941]\nジャケット、シャツ、パンツ、どんなポケットにも収まるミニサイズのマルチパースです。携帯性に優れたサイズ感と適度な収納性が程良いバランスで仕上がっています。",
                        "[FRED PERRY:NECK JUMPER]\nチャンキーリブのトリムが特徴的な、温かいクルーネックのセーター。エシカルな方法で調達したラムウールで編みこまれています。",
                        "[EMPORIO ARMANI:ベルト]\n洗練されたトレンド感のあるデザインが魅力的な、毎日使いのアクセサリー。エンポリオ アルマーニのスタイルは、レザー小物にもしっかりと表れます。",
                    "[Knirps:T.200]\n使う人に優しい自動開閉機能付き、シャフトの不意な飛び出しを防ぐ「セーフティー・システム」を採用しています。アルミニウム、スチールを使用したシャフトで安定性が保障されています。"
            ]
        
        let label2Array: NSArray = [
            "¥22,000",
            "¥57,200",
            "¥21,990",
            "¥38,500",
            "¥75,900",
            "¥38,500",
            "¥22,000",
            "¥20,900",
            "¥18,700",
            "¥8,030"]
    let URLlink: [String] = [
                "https://www.ganzo.ne.jp/fs/ganzo/57189",
                "http://www.union-royal.jp/item/unionimperial/prestige/su202.html",
                "https://www.braun.jp/ja-jp/male-grooming/shavers-for-men/series-9/series-9-pro-9455cc",
                "https://www.bulgari.com/ja-jp/39341.html",
                "https://japan.tommy.com/shop/item/MW19681000?colorCode=DW5&utm_source=google&utm_medium=cpc&utm_campaign=g_dy&utm_content=g_men&utm_source=google&utm_medium=cpc&utm_campaign=shopping&gclid=Cj0KCQiA-qGNBhD3ARIsAO_o7ynyLHFyvheRugEX9eqtSBfohy1MR4oVWvY_omqcPG1xf0VZDtCDs28aAuKLEALw_wcB",
                "https://www.parigot.jp/c/brand/johnstons/2204005339464",
                "https://www.frame.jp/products/detail/32630",
                "https://www.fredperry.jp/category/M_KNIT/K9535.html",
                "https://www.armani.com/ja-jp/%E3%83%99%E3%83%AB%E3%83%88-%E3%82%B9%E3%83%A0%E3%83%BC%E3%82%B9%E3%82%AB%E3%83%BC%E3%83%95%E3%82%B9%E3%82%AD%E3%83%B3%E8%A3%BD_cod22250442025726033.html",
                "https://knirps.shop-pro.jp/?pid=128694873"]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

