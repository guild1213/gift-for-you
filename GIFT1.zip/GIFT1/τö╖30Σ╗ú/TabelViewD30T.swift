//
//  ViewController.swift
//  GIFT
//
//  Created by 二宮大智 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TabelViewD30T: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-30-t-1-1",
            "d-30-t-2-1","d-30-t-3-1",
            "d-30-t-4-1","d-30-t-5-1",
            "d-30-t-6-1","d-30-t-7-1",
            "d-30-t-8-1","d-30-t-9-1",
            "d-30-t-10-1"]
        
        let img1Array: NSArray = [
            "d-30-t-1-2",
            "d-30-t-2-2","d-30-t-3-3",
            "d-30-t-4-2","d-30-t-5-2",
            "d-30-t-6-2","d-30-t-7-2",
            "d-30-t-8-2","d-30-t-9-2",
            "d-30-t-10-2"]
        
        let img2Array: NSArray = [
            "d-30-t-1-3",
            "d-30-t-2-3","d-30-t-3-2",
            "d-30-t-4-3","d-30-t-5-3",
            "d-30-t-6-3","d-30-t-7-3",
            "d-30-t-8-3","d-30-t-9-3",
            "d-30-t-10-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
        let label1Array: NSArray = [
        "[Zegna:100fili]\n独自開発による100fili生地から作られたこのタイは、1センチメートル当たり100スレッドカウントを超えるピュアシルク糸から、極めて滑らかな手触りが生み出されています。",
        "[Daito:マッサージャー MD-8671]\n椅子やソファでの使用はもちろん、床において寝ながらの使用が可能で自動コースは全4種類、従来の全身・肩・腰に加え、寝て使用時に特に気持ちいい「ストレッチコース」もあります。",
        "[Opus One:Opus One 2018]\nブラックベリー、カシス、ブラックチェリーの豊かな香りから、上品なスミレ、白胡椒、そしてバラの花びらへと続き、とても魅力的な芳香を放ちます。",
        "[Orobianco:MAGRO]\n本革を使用し、シックな仕上がりとなっているためビジネスバッグとしてだけでなく、普段使いできるなど幅広い年代で愛されている1品となっております。",
        "[Paul Smith:ドレスシャツ]\nポール・スミスのアーカイブブックの写真がインスピレーションになったグラフィックフラワー、\"Archive Floral\"のプリントが織りで表現されたドレスシャツです。",
        "[HERMES:アジャンダカバー]\n不規則ながら調和のとれたグレイン、軽い光沢を持つヤギ革の持ち味が特徴で一方向だけでなく、複数の方向に細いラインをつけることもできます。",
        "[BURBERRY:アイコンストライプディテール]\nシンプルなパラジウムにロゴだけを刻印したアイコンストライプをエナメル加工であしらったパラジウムメッキのタイバーです。",
        "[DIESEL:HIRESH S]\nナチュラルなシボ感が特徴的なレザーを採用した「THEBEIS」シリーズでDIESELのリベットロゴデザインがワンポイントになっています。",
        "[PARKER:ソネット]\nベーシックなブラックのボディにゴージャスに輝くゴールドをコーディネート。ボディとのコントラストが際立ちます。",
        "[EMRORIO ARMANI:ポケットチーフ]\nポケットチーフは、ジャケットにさり気ないエレガンスをプラスします。メンズアクセサリーの象徴というべき、真にスタイリッシュな男性像を演出する華やかなディテールです。"]
        
        let label2Array: NSArray = [
            "¥25,300",
            "¥43,780",
            "$430",
            "¥47,300",
            "¥22,000",
            "¥47,300",
            "¥34,100",
            "¥16,280",
            "¥13,200",
            "¥13,200"]
        let URLlink: [String] = [
        "https://www.zegna.com/jp-ja/%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B5%E3%83%AA%E3%83%BC/%E3%83%8D%E3%82%AF%E3%82%BF%E3%82%A4-%E3%83%9D%E3%82%B1%E3%83%83%E3%83%88%E3%83%81%E3%83%BC%E3%83%95/product.10490083/",
        "https://daito-thrive.co.jp/store/products/detail.php?product_id=450",
        "https://jp.opusonewinery.com/current-releases/",
        "https://orobianco-jp.com/f/dsg-2313783",
        "https://www.paulsmith.co.jp/shop/men/paul-smith/dress_shirts/products/2132077100800PN___",
        "https://www.hermes.com/jp/ja/product/%E3%82%A2%E3%82%B8%E3%83%A3%E3%83%B3%E3%83%80%E3%82%AB%E3%83%90%E3%83%BC-%E3%80%8Apm%E3%80%8B-H028175CA89/",
        "https://jp.burberry.com/logo-detail-palladium-plated-tie-bar-p80356921",
        "https://www.diesel.co.jp/products/detail.php?product_id=2304541&brand=diesel&subcat=men&classcategory_id1=2326035",
        "https://www.ito-ya.co.jp/item/35011795078421.html",
        "https://www.armani.com/ja-jp/%E3%83%9D%E3%82%B1%E3%83%83%E3%83%88%E3%83%81%E3%83%BC%E3%83%95-%E3%83%94%E3%83%A5%E3%82%A2%E3%82%B7%E3%83%AB%E3%82%AF%E8%A3%BD-%E3%83%80%E3%82%A4%E3%83%A4%E3%83%A2%E3%83%B3%E3%83%89%E3%83%A2%E3%83%81%E3%83%BC%E3%83%95_cod20346390236391672.html"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}
