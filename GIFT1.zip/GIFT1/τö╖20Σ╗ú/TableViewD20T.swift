//
//  TableViewD20T.swift
//  GIFT
//
//  Created by 二宮大智 on 2021/11/25.
//

import UIKit
import SafariServices
 
class TabelViewD20T: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-20-t-1-1",
            "d-20-t-2-1","d-20-t-3-1",
            "d-20-t-4-1","d-20-t-5-1",
            "d-20-t-6-1","d-20-t-7-1",
            "d-20-t-8-1","d-20-t-9-1",
            "d-20-t-10-1"]
        
        let img1Array: NSArray = [
            "d-20-t-1-2",
            "d-20-t-2-2","d-20-t-3-2",
            "d-20-t-4-2","d-20-t-5-2",
            "d-20-t-6-2","d-20-t-7-2",
            "d-20-t-8-2","d-20-t-9-2",
            "d-20-t-10-2"]
        
        let img2Array: NSArray = [
            "d-20-t-1-3",
            "d-20-t-2-3","d-20-t-3-3",
            "d-20-t-4-3","d-20-t-5-3",
            "d-20-t-6-3","d-20-t-7-3",
            "d-20-t-8-3","d-20-t-9-3",
            "d-20-t-10-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
        let label1Array: NSArray = [
        "[ブルガリ:ビジネスカードホルダー]\nマットなブラックのエナメル加工で、名刺を入れるスペースが広いため営業職などで頻繁に使う方でも安心です。",
        "[GUCCI:コインウォレット]\n1970年代に人気を博したこのラインのシンボル、ダブルG ハードウェアのミニバージョンがアクセントになっています。",
        "[IL BISONTE:キーケース]\n上質な牛革で有名のIL BISONTE。カラーが2種類あり、サイドにはストラップを掛けるためのリングも取り付けできるためデザインだけでなく機能面でも優れています。",
        "[バランタイン 21年物]\n最低21年以上熟成されており、リンゴや花の芳香な香りがします。お酒好きには必ず一度は飲んでみたい品物です。",
        "[AKEO KIKUCHI:ストライプ柄のネクタイ]\n上品なボックスに入ったタイバー付きセットはギフトに非常におすすめです。高級感がありながらもシンプルなイメージに仕上げたネクタイです。",
        "[Paul Smith:Closed Eyes]\nヴァーティカルストライプとホリゾンタルヘアラインの交差で描かれたアイコニックなクロスが目を引く、シンプル＆クリーンな1本です。",
        "[Supreme:S Logo Split]\n左胸にシルエットとなるSがデザインされており、コットンを使用しているため肌触りが良く値段以上のパフォーマンスを発揮してくれます。",
        "[dunhill:レザーベルト]パラジウム仕上げの長方形バックルが特徴の30mm幅ベルト。 ブラックのレザーは、表がカドガンレザー、裏がスムースレザーのリバーシブルとなっております。",
        "[Ray・Ban:RB2140F 901SR5 52-22]\nRayBanと木村拓哉さんとのコラボで、木村氏の手書きによる「Takuya. K」のサインが刻印されています。",
        "[MAVERICK & CO.:METROPOLITAN]\n本革を使用しており大人のシックな印象を与えつつ、ノートパソコンも入れることができるサイズになっているため社会人の通勤としても使うことができます。"]
        
        let label2Array: NSArray = [
            "¥39,600",
            "¥63,800",
            "¥16,500",
            "¥22,000",
            "¥15,400",
            "¥39,600",
            "¥29,700",
            "¥42,900",
            "¥26,400",
            "¥33,900"]
        let URLlink: [String] = [
            "https://www.bulgari.com/ja-jp/280297.html",
            "https://www.gucci.com/jp/ja/pr/men/small-leather-goods-for-men/bifold-wallets-for-men/gg-marmont-coin-wallet-p-4287250YK0N1000",
            "https://www.ilbisonte.jp/shop/onlinestore/item/view/shop_product_id/2669/color_id/240",
            "https://www.ballantines.ne.jp/products/21years.html",
            "https://store.world.co.jp/brand/takeo-kikuchi/item/BR07021F0134?areaid=sp070_takeo",
            "https://www.paulsmith.co.jp/shop/men/accessories/watches/products/8632386200BLACK___?sku=8632386200BLACK___990F",
            "https://www.supremenewyork.com/shop/sweatshirts/pie1rtd4p",
            "https://www.dunhill.com/jp/%E3%83%99%E3%83%AB%E3%83%88_cod22010819fe.html",
            "https://www.ray-ban.com/japan/sunglasses/RB2140F%20UNISEX%20wayfarer-%E3%83%9E%E3%83%83%E3%83%88%E3%83%96%E3%83%A9%E3%83%83%E3%82%AF/8056597483261",
            "https://jp.maverickandco.co/collections/backpacks/products/metropolitan-business-backpack"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}
