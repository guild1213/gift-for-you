//
//  TableViewD20C.swift
//  GIFT
//
//  Created by 朝倉健登 on 2021/11/25.
//

import UIKit
import SafariServices
 
class TableViewD20C: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-20-c-1-1",
            "d-20-c-2-1","d-20-c-3-1",
            "d-20-c-4-1","d-20-c-5-1",
            "d-20-c-6-1","d-20-c-7-1",
            "d-20-c-8-1","d-20-c-9-1"
            ,"d-20-c-10-1"
]
        
        let img1Array: NSArray = [
            "d-20-c-1-2",
            "d-20-c-2-2","d-20-c-3-2",
            "d-20-c-4-2","d-20-c-5-2",
            "d-20-c-6-2","d-20-c-7-2",
            "d-20-c-8-2","d-20-c-9-2",
            "d-20-c-10-2",]
        
        let img2Array: NSArray = [
            "d-20-c-1-3",
            "d-20-c-2-3","d-20-c-3-3",
            "d-20-c-4-3","d-20-c-5-3",
            "d-20-c-6-3","d-20-c-7-3",
            "d-20-c-8-3",
            "d-20-c-9-3","d-20-c-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[Apple Watch]\nAppleのAppleWatchは日々の生活が便利になるだけでなく健康状態を把握でき、デザインも先進的なのでかなりの人気があります。",
                        "[LACOSTE:スプリングコート]\nベーシックなディテールで構成しつつ、適度なオーバーサイズシルエットでトレンド感あふれる一枚となっています。",
                        "[Apple:AirPods Pro]\n AirPods ProはAppleのイヤフォンで初のノイズキャンセリング機能を搭載しており、音質も従来のものより向上しているため幅広い世代で好まれています。",
                        "[amazon:Kindle]\nタブレットでは珍しく防水仕様のためお風呂やプールなど様々な場面で読書を楽しむことができます。ステイホームで読書が流行っているのでおすすめです。",
                        
                        "[BRITISH MADE:タータンテックスカーフ]やみつきになる柔らかさと暖かさのある上質なカシミヤマフラーは、首にひと巻きするだけで滑らかなドレープが生まれ、上質感が漂います。",
                        "[patagonia:グレイシャージャケット]\nシルエットがアウトドアブランドにありがちなデザインでなく、カジュアルに着こなすことができるため多彩な場面で活躍します。",
                        "[Panasonic:リニアシェーバー ラムダッシュ]\n多くのヒゲを一度に根元深くからとらえて、肌にやさしく深剃り。他の追随を許さない極上の剃り味で、未体験のシェービングを実現します。",
                        "[REGAL: プレーントウ]\n当時日本のファッションシーンでは絶大な支持を集め、誰もがこの靴を履くことにステータスを感じ、我先にと 奪い合ったとされる伝説の革靴です。",
                        "[PORTER:3WAY BRIEFCASE]\n耐久性と耐水性に優れた2種類の異なる素材を組み合わせ、無骨でスタイリッシュなデザインが魅力の「HEAT（ヒート）」シリーズです。",
                    "[Pelikan:スーベレーン]\nスーべレーンとは優れているという意味で、全てが手作業で仕上げられるため温もりと職人の確かな技を感じられる逸品です。"
            ]
        
        let label2Array: NSArray = [
            "¥54,300",
            "¥39,600",
            "¥30,580",
            "¥14,980",
            "¥38,500",
            "¥50,600",
            "¥44,000",
            "¥33,000",
            "¥44,550",
            "¥41,800"]
    let URLlink: [String] = [
                "https://www.apple.com/jp/shop/buy-watch/apple-watch",
                "https://www.lacoste.jp/products/BH062EL/02S?gclsrc=aw.ds&%3Futm_source=google&utm_medium=shopping&utm_campaign=ssc&gclid=Cj0KCQiAys2MBhDOARIsAFf1D1cljd7iIov16l1JrnbkNvAD3EH6DRJItwN3H7nOLMce4UAU8_JBPAAaAkmiEALw_wcB",
                "https://www.apple.com/jp/airpods-pro/",
                "https://www.amazon.co.jp/dp/B08N41Y4Q2?tag=googhydr-22&ref=pd_sl_13m3hq2pnd_e",
                "https://www.british-made.jp/c/all/men/mens_stole/JOE92750000000",
                "https://www.patagonia.jp/product/mens-jackson-glacier-jacket/27920.html?dwvar_27920_color=NORG&cgid=mens-down-casual",
                "https://panasonic.jp/shaver/products/lamdash6.html",
                "https://shoes.regal.co.jp/shop/g/g07ALCJ_____BURG_235",
                "https://www.yoshidakaban.com/product/101340.html",
                "https://i-penstar.com/SHOP/ppeli041.html"]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

