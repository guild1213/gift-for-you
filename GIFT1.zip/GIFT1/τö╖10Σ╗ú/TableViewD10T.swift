//
//  tabel view.swift
//  GIFT1
//
//  Created byon 2021/10/17.
//

import UIKit
import SafariServices
 
class TabelViewD10T: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-10-t-1-1",
            "d-10-t-2-1","d-10-t-3-1",
            "d-10-t-4-1","d-10-t-5-1",
            "d-10-t-6-1","d-10-t-7-1",
            "d-10-t-8-1","d-10-t-9-1",
            "d-10-t-10-1"]
        
        let img1Array: NSArray = [
            "d-10-t-1-2",
            "d-10-t-2-2","d-10-t-3-2",
            "d-10-t-4-2","d-10-t-5-2",
            "d-10-t-6-2","d-10-t-7-2",
            "d-10-t-8-2","d-10-t-9-2",
            "d-10-t-10-2"]
        
        let img2Array: NSArray = [
            "d-10-t-1-3",
            "d-10-t-2-3","d-10-t-3-3",
            "d-10-t-4-3","d-10-t-5-3",
            "d-10-t-6-3","d-10-t-7-3",
            "d-10-t-8-3","d-10-t-9-3",
            "d-10-t-10-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
        let label1Array: NSArray = [
            "[TOMMY HILFIGER:ロゴレザーウォレット]\n10代男性に最も人気のブランド、TOMMY HILFIGER。高校生から大学生まで幅広く使えるよう大人っぽい折りたたみ財布が今人気です",
            "[BEATS:FLEX]\n通学など豊富な場面で使えるBeatsのワイヤレスイヤホン。最大12時間、再生することができ、カラーが豊富なため好みに合わせてプレゼントすることができます。",
            "[Carhartt:FLINT BACKPACK - Black]\n古着などで有名なカーハートのリュックサック。コーデュロイの生地を使っているため、みんなとは少し違うプレゼントを渡したい方にオススメです。",
            "[ナイキ:AIR FORCE 1 '07]\n王道のNIKE、エアフォース1。ポピュラーなホワイト/ホワイトから、オリジナリティーを出したい方は+4500円〜自分好みにカスタマイズすることもできます。",
            "[Patagonia:メンズ・ロングスリーブ・P-6ロゴ・レスポンシビリティー]\n10代男性に圧倒的人気のPatagonia。ロングスリーブのため1年を通して着る機会が高いためプレゼントに最適です！",
            "[KLON:HIDE TIME BLACK 40mm]\nシンプルなデザインが男女問わず人気なKLON。文字盤のデザインが少し違う物もあり、バリエーションが豊富です。",
            "[iFace]\n幅広い年代で愛用されるiFace。背面が透明のものから人気のカラーまでさまざまな種類があり、ご自身のセンスで無限大の可能性が広がっています。",
            "[OCEAN TRICO:No.1　テンコモリセット]\nメンズヘアワックスの中で、最も人気のオーシャントリコ。この1セットで多様なスタイリングとヘアケアができるため、迷っている方にはおすすめです",
            "[SHIRO:サボン オードパルファン]\nシンプルなデザインでいま人気急増中のshiro。香りは、みずみずしく爽やかに香る「サボン」は女性からの人気も高いです。",
            "[Hippopotamus:フェイスタオル]\n上質な肌触りをしているHipopotamusのフェイスタオル。吸水性が高くミニバスタオルのように身体を拭くこともができます。"]
        
        let label2Array: NSArray = [
            "¥11,000",
            "¥8,400",
            "¥10,780",
            "¥11,000〜",
            "¥6,050",
            "¥7,950〜¥15,180",
            "¥3,520〜",
            "¥8,800",
            "¥4,180",
            "¥3,850"]
        let URLlink: [String] = [
            "https://japan.tommy.com/shop/item/AM07814000?colorCode=BDS&shopCode=MEN",
            "https://www.beatsbydre.com/jp/earphones/beats-flex",
            "https://carhartt-wip.jp/products/i029504-21f-89xx?_pos=13&_sid=9298698ca&_ss=r",
            "https://www.nike.com/jp/t/%E3%83%8A%E3%82%A4%E3%82%AD-%E3%82%A8%E3%82%A2-%E3%83%95%E3%82%A9%E3%83%BC%E3%82%B9-1-07-%E3%83%A1%E3%83%B3%E3%82%BA%E3%82%B7%E3%83%A5%E3%83%BC%E3%82%BA-J16CJp/CW2288-111",
            "https://www.patagonia.jp/product/ms-l/s-p-6-logo-responsibili-tee/38518.html?dwvar_38518_color=BLK&cgid=mens-t-shirts-long-sleeve",
            "https://klonklonklon.com/?pid=116554786",
            "https://jp.iface.com/products",
            "https://oceantrico.com/product/%E2%98%85no-1%E3%80%80%E3%83%86%E3%83%B3%E3%82%B3%E3%83%A2%E3%83%AA%E3%82%BB%E3%83%83%E3%83%88/",
            "https://shiro-shiro.jp/category/245/12116.html",
            "https://hippopotamus.co.jp/collections/face-towels/products/face-towel"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}
