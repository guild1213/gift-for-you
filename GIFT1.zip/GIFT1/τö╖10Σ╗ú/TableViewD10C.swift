//
//  tableview2.swift
//  GIFT1
//
//  Created by 朝倉健登 on 2021/11/15.
//
import UIKit
import SafariServices
 
class TableViewD10C: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-10-c-1-1",
            "d-10-c-2-1","d-10-c-3-1",
            "d-10-c-4-1","d-10-c-5-1",
            "d-10-c-6-1","d-10-c-7-1",
            "d-10-c-8-1","d-10-c-9-1"
            ,"d-10-c-10-1"
]
        
        let img1Array: NSArray = [
            "d-10-c-1-2",
            "d-10-c-2-2","d-10-c-3-2",
            "d-10-c-4-2","d-10-c-5-2",
            "d-10-c-6-2","d-10-c-7-2",
            "d-10-c-8-2","d-10-c-9-2",
            "d-10-c-10-2",]
        
        let img2Array: NSArray = [
            "d-10-c-1-3",
            "d-10-c-2-3","d-10-c-3-3",
            "d-10-c-4-3","d-10-c-5-3",
            "d-10-c-6-3","d-10-c-7-3",
            "d-10-c-8-3",
            "d-10-c-9-3","d-10-c-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[POLO RALPH LAUREN: スカーフ]\nマフラーの人気ブランドであるラルフローレン\nブラックとグレーのリバーシブルになっており大人っぽい印象を与えつつ、気分に合わせてコーデすることができます",
                        "[starbucks: ロゴマグブラック]\n長く使えるスターバックスコーヒーのマグカップ店内で使用しているマグカップと同じ形状なのでご自宅でお店の雰囲気を味わうことができます",
                        "[今治浴巾:イデゾラ オムパジャマ]\nバスタオルなどで有名な今治タオルの素材を使った上下セットのパジャマ。密に織り上げた表面の平織り生地はやわらかく光沢があります。",
                        "[VANS:CANVAS ALL STAR OX]\n学生から絶大な人気を誇るコンバース。そのなかでもポピュラーなチャックテイラーがランクイン。制服からプライベートの服までさまざまな場面で活躍します。",
                        
                        "[THE NORTH FACE:カプッチョリッド]\nTHE NORTH FACEのニット帽。幅広い男性から人気で縫い目のないホールガーメント製法で仕上げたビーニーが特徴です。",
                        "[Calvin Klein:ボクサーパンツ ]\n身体の凹凸に沿うようコンパクトにデザインされており、快適な履き心地を実現しています。アンダーウェアは人によって好みがあるのでその人に合ったタイプを選んであげてください。",
                        "[DISEL :B-STRAIGHT]\nDISELのベルトはさまざまな種類が展開されていますがそのなかでもシンプルなものが人気です。本革を使用しているため使えば使うほど味が出てきます",
                        "[Champion: フーデッドスウェットシャツ]\nパーカーで最も有名のChampion。肌触りの良いコットン100％の裏起毛素材を使用したフーデッドスウェットシャツで真冬でも1枚で過ごすことができます。",
                        "[RALPH LAUREN:Polo ベア コットン グローブ]\nRALPH LAURENのpoloベアの手袋は肌触りの良いコームドコットンを使用しており、poloベアが学生風バージョンになっているのも人気の一つです。",
                        "[ライジングウェーブ:フリー]\nRISINGWAVEのフリーシリーズは4種類で展開しておりその人をイメージした香りをプレゼントでき、どれもフルーティーな香りになっているためオールシーズンで使用できます。"
            ]
        
        let label2Array: NSArray = [
            "¥13,200",
            "¥1,430",
            "¥11,000",
            "¥6,300",
            "¥4,180",
            "¥6,380",
            "¥8,800",
            "¥6,600",
            "¥9,790",
            "¥3,300"]
    let URLlink: [String] = [
                "https://www.ralphlauren.co.jp/category/GOODS_TYPE/60828646.html",
                "https://product.starbucks.co.jp/goods/mug/4524785245396/?category=goods%2Fmug&place=3",
                "https://imabariyokkin.com/fs/imabariyokkin/gr23/5031461",
                "https://shop.converse.co.jp/shop/g/g32160321210/",
                "https://www.goldwin.co.jp/ap/item/i/m/NN42035",
                "https://japan.calvinklein.com/shop/item/NB1086?colorCode=BHY",
                "https://www.diesel.co.jp/products/detail.php?product_id=2309280&brand=diesel&subcat=men&classcategory_id1=2330627",
                "https://www.hanesbrandsinc.jp/champion/g/gC3-Q107-070-S/",
                "https://www.ralphlauren.co.jp/category/GT2086/60750536.html",
                "https://fitsonlinestore.com/c/risingwave/311204864"]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

