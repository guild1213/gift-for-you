//
//  TableViewCell.swift
//  GIFT1
//
//  Created by  on 2021/11/17.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var page: UIPageControl!
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var button: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
