//
//  TableViewJ20K.swift
//  GIFT1
//
//  Created by 久保田凌也 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TableViewJ20K: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-10-k-1-1",
            "j-20-k-2-1","d-20-k-4-1",
            "d-20-k-3-1","d-20-k-5-1",
            "j-20-k-6-1","j-20-k-7-1",
            "j-20-k-8-1","d-20-k-10-1",
            "j-20-k-10-1"]
        
        let img1Array: NSArray = [
            "d-10-k-1-2",
            "j-20-k-2-2","d-20-k-4-2",
            "d-20-k-3-2","d-20-k-5-2",
            "j-20-k-6-2","j-20-k-7-2",
            "j-20-k-8-2","d-20-k-10-2",
            "j-20-k-10-2"]
        
        let img2Array: NSArray = [
            "d-10-k-1-3",
            "j-20-k-2-3","d-20-k-4-3",
            "d-20-k-3-3","d-20-k-5-3",
            "j-20-k-6-3","j-20-k-7-3",
            "j-20-k-8-3","d-20-k-10-3",
            "j-20-k-10-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
    let label1Array: NSArray = [
        "[ペアチケット]\n二人の記念日を特別の思い出にすることができること間違いなしのディズニーやユニバーサルのパークチケット。キャラクターとの触れ合いや食事なども楽しむことができます。",
                "[SOW EXPERIENCE:FOR2]\nさまざまなジャンルの体験が選べるFOR2（フォーツー）ギフト。REDはGREENよりも本格的なアクティビティや、食事などが充実しています。",
                "[DANIEL WELLINGTON:ELAN RING]\n男女ともに愛される美しいシルエットで上品な見た目がベースになっておりどんな装いにも華を添えます。",
                "[agnes b.: FCRK986]\nエレガントで洗練されたタイムレスなデザインでマルチェロのアイコンともいうべき2針の薄型モデルです。",
                "[LACISTE:L!VE ネームプリントラガーシャツ]\n布帛の袖に比翼の前立てをセットしておりベビーオンスのコットンジャージを使用したベーシックディティールのラガーシャツです。",
                "[TIFFANY&Co.:オープンハートペンダント]\n愛することへの祝福の意が込められた、シンプルで刺激的なシェープのエルサ・ペレッティオープンハ―ト。エレガントなスタイルを体現したアイコン的デザインです。",
                "[TANP:入浴剤&Relax Gift-BLUE ]\nリラックスチケットと、一週間分のクレイ入浴剤をブックパッケージにしたCLAYD Weekbookセット。エクササイズ、ネイルなどのリフレッシュやビューティがテーマの体験できます。",
                "[Sakaseru:ドライフラワー]\nドライフラワーとプリザーブドフラワーをガラスの中に閉じ込めました。お花の色味は、贈り先様のイメージカラー等ご希望に合わせてお作り可能です。",
                "[メッセージギフト]\n相手の名前やお互いの名前から詩を作ることができます。人柄やエピソードなどを反映することもでき、特別な2人の思い出を形に残すことができます。",
                "[STARBUCKS:ロゴ マグ ブラック ペア]\nマットな質感の黒いボディにロゴがプリントされた、シンプルなデザインで、店内で使用しているマグカップと同じ形状で、名前などが彫刻できます。"]
    
    let label2Array: NSArray = [
        "¥13,200〜¥18,800",
        "¥22,550",
        "¥13,860",
        "¥51,700",
        "¥41,800",
        "¥30,250",
        "¥9,900",
        "¥11,000",
        "¥12,650",
        "¥9,900"]
    let URLlink:[String] = [
        "https://www.tokyodisneyresort.jp/ticket/index.html",
        "https://www.sowxp.co.jp/catalogs/539",
        "https://www.danielwellington.com/jp/dw-ring-elan-ring-rose-gold-48/",
        "https://www.agnesb-watch.jp/p_search/details.php?no=FCRK986",
        "https://www.lacoste.jp/products/DH9421L/031",
        "https://www.tiffany.co.jp/jewelry/necklaces-pendants/elsa-peretti-open-heart-pendant-GRP06386/",
        "https://tanp.jp/products/view/1276",
        "https://www.sakaseru.jp/lp/business/ready-made-item/46?gclid=CjwKCAiAhreNBhAYEiwAFGGKPMpsHbQ6WSFBUGc860c8VdOXXvBaffmBnx9oHgktn-Tk1MZCy0VTMRoCkKoQAvD_BwE",
        "https://giftmall.co.jp/gift2IoAhr/?gsf_pcid=131318%3A0%3A0&gclid=Cj0KCQiAhf2MBhDNARIsAKXU5GTrwOo7GAsC3eAGImhkUhAikmvjCp5CaoIma5TXfhKRPYnRWr5_9Y0aAtd-EALw_wcB",
        "https://giftmall.co.jp/giftXS1W0i/?gsf_pcid=805126%3A0%3A0&gclid=CjwKCAiAhreNBhAYEiwAFGGKPAe6WR1JFds7MpLMCHEN2vUbyT4EVm1jhJ5TIu49Tdv2ajD8kVU4dBoCAGQQAvD_BwE"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


