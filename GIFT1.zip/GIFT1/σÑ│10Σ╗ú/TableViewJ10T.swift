//
//  TableViewJ10C.swift
//  GIFT
//
//  Created by 朝倉健登 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TableViewJ10T: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "j-10-t-1-1",
            "j-10-t-2-1","j-10-t-3-1",
            "j-10-t-4-1","j-10-t-5-1",
            "j-10-t-6-1","j-10-t-7-1",
            "j-10-t-8-1","j-10-t-9-1"
            ,"j-10-t-10-1"
]
        
        let img1Array: NSArray = [
            "j-10-t-1-2",
            "j-10-t-2-2","j-10-t-3-2",
            "j-10-t-4-2","j-10-t-5-2",
            "j-10-t-6-2","j-10-t-7-2",
            "j-10-t-8-2","j-10-t-9-2",
            "j-10-t-10-2",]
        
        let img2Array: NSArray = [
            "j-10-t-1-3",
            "j-10-t-2-3","j-10-t-3-3",
            "j-10-t-4-3","j-10-t-5-3",
            "j-10-t-6-3","j-10-t-7-3",
            "j-10-t-8-3",
            "j-10-t-9-3","j-10-t-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[ipsa/ザ・タイムR アクア]\nうるおい成分を抱えた水の層を肌表面につくり、キメを整え、ぷるぷると水をまとったようなみずみずしい感触を持続させる薬用化粧水です。",
                        "[YVESAINTLAURENT:ルージュ]\nとろける色艶を叶えるYSL No.1リップ。 写真やカメラ機能を使って、ご自宅でもカラーシミュレーションが可能です。 公式サイト限定の選べるギフトラッピングでプレゼントにおすすめです。",
                        "[4℃:シルバーブレスレッド]\nピンクシルバー素材の大小ハートとキュービックジルコニアが交互に並んだ大人っぽくかわいいデザインのブレスレットです。",
                        "[CHANEL:チャンス オー タンドゥル]\nフルーティなグレープフルーツ、やわらかいジャスミン、そしてなめらかなホワイト ムスクが絡み合う、チャンス オー タンドゥルの香りがするヘア ミストです。",
                        
                        "[LUSH:ハッピーバスデイギフト]\n大切な人の誕生日にふさわしいギフトには6種類の入浴剤が詰まっています。あっと驚く仕掛けもあるので乞うご期待です。",
                        "[DIOR:バックステージ アイパレット]\nメイクアップ アーティストの必須アイテムを集めたパレットには、プライマー、シェードによってマット・パーリー・メタリックの仕上がりのアイシャドウ、ハイライト、ライナーが配置されています。",
                        "[gelatopique:ベア柄ポーチ]\n様々なポーズをとるベアのぬいぐるみを総柄であしらった愛らしいティッシュポーチ。少しずつ色の異なるベアたちが単調にならず、デザインに奥行きをもたらします。",
                        "[COACH:スキニーIDケース]\nややテクスチャー感のあるクロスグレインレザーで仕上げたIDケース。ミニマルなデザインながら、カード、キャッシュなどを収納できIDウィンドウとカードスロット付きです。",
                        "[AVEDA:パドルブラシ]\nブラシ部分が頭皮に刺激を与え、心地よいブラッシングを可能にするヘアブラシです。ブロードライやスタイリング時の髪や頭皮への負担を緩和するようデザインされており、空気穴がほどこしてあります。",
                    "[Over the Rainboo! Boo Boo CREAM]\nいつものスキンケア後に下地クリームとして使い、お好きなファンデーションやパウダーを重ねてもOKでベースメイクがもちよく、キレイに決まります。"
            ]
        
        let label2Array: NSArray = [
            "¥4,400",
            "¥4,510",
            "¥11,000",
            "¥5,280",
            "¥5,840",
            "¥6,050",
            "¥2,750",
            "¥9,900",
            "¥3,740",
            "¥5,378",
            ]
    let URLlink: [String] = [
                "https://www.ipsa.co.jp/43252.html?lang=ja&cgid=skincare-category-toner#lang=ja&start=2",
                "https://www.yslb.jp/makeup/makeup-lips/makeup-lipstick/rouge-volupte-shine/144YSL.html#start=4&cgid=makeup-lips",
                "https://www.fdcp.co.jp/4c-jewelry/jewelry/111344131102",
                "https://www.chanel.com/jp/fragrance/p/126780/chance-eau-tendre-hair-mist/",
                "https://www.lush.com/jp/ja/p/happy-bathday-gift",
                "https://www.dior.com/ja_jp/products/beauty-Y0012000_C001200003?gclid=Cj0KCQiA47GNBhDrARIsAKfZ2rDJiLBr_fSZ5aNdU_wmQB0pR6RzGXa42P3ZVaLagE6C7E_IG0P0DgoaAheiEALw_wcB",
                "https://gelatopique.com/Form/Product/ProductDetail.aspx?shop=0&pid=PWGB215745&vid=&bid=PIQ01&cat=WOM006004&swrd=",
                "https://japan.coach.com/goods/57841?color=V5O4Q&DISP_NO=005002003006&positionId=127129",
                "https://www.aveda.jp/product/17775/16651/aveda-wooden-paddle-brush#/shade/%E3%83%AF%E3%83%B3%E3%82%B5%E3%82%A4%E3%82%BA",
                "https://overtherainboo.com/products/booboocream"]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

