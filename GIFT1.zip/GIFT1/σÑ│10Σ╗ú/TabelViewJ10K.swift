//
//  ViewController.swift
//  GIFT
//
//  Created by 二宮大智 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TabelViewJ10K: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-10-k-1-1",
            "d-10-k-2-1","d-10-k-3-1",
            "d-10-k-4-1","d-10-k-5-1",
            "d-10-k-6-1","d-10-k-7-1",
            "d-10-k-8-1","d-10-k-9-1",
            "d-10-k-10-1"]
        
        let img1Array: NSArray = [
            "d-10-k-1-2",
            "d-10-k-2-2","d-10-k-3-2",
            "d-10-k-4-2","d-10-k-5-2",
            "d-10-k-6-2","d-10-k-7-2",
            "d-10-k-8-2","d-10-k-9-2",
            "d-10-k-10-2"]
        
        let img2Array: NSArray = [
            "d-10-k-1-3",
            "d-10-k-2-3","d-10-k-3-3",
            "d-10-k-4-3","d-10-k-5-3",
            "d-10-k-6-3","d-10-k-7-3",
            "d-10-k-8-3","d-10-k-9-3",
            "d-10-k-10-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
    let label1Array: NSArray = [
        "[ペアチケット]\n二人の記念日を特別の思い出にすることができること間違いなしのディズニーやユニバーサルのパークチケット。キャラクターとの触れ合いや食事なども楽しむことができます。",
        "[手作りペアリング]\n2人でつくる思い出のペアリング。お値段もお手軽で時間も1時間から2時間ほどで完成するのでデートの一つとして気軽に作ることができます。",
        "[Lee:コーデュロイポケット付き パーカー]\n生地と同系色のコーデュロイ素材でシンプルに仕上げており、ユニセックスなのでペアルックでおしゃれに着ることができます。",
        "[KLON:tentosen GOLD model]\nKLONのペアルックウォッチ。\nシンプルなデザインで、カジュアルからフォーマルまで、場所を選ばずご使用いただけます。",
        "[フォトフレーム]\n2人の思い出を形に残すことができるフォトアルバム。形に残すことで記念日が訪れるたびに増えていくアルバムは後で見返すことができます。",
        "[トムとジェリーのスマホケース]\n1日のほとんど持ち歩いているため常に相手のことを思うことができ、トムとジェリーは男女ともに人気のためおすすめです。",
        "[agnes b:RAH09－01 キーホルダー]\nブラックとホワイトの色使いがアニエスベーらしいキーホルダー。テープ部分には、b.ロゴのモチーフが入っており、ダミーのカギが遊び心もあります。",
        "[Canal4°C:ペアブレスレット]\n4℃は男女ともに人気であり、ふたつのブレスレットを重ねるとハートが浮かび上がるペアブレスレット。男性にはスタイリッシュな印象を、女性にはガリーな印象を与えてくれます。",
        "[VANS:オールドスクール]\nスニーカーのなかでも人気なVANSのなかでも不動の人気を誇るオールドスクール。どんなスタイルにもマッチしやすいベーシックなデザインでペアシューズにはぴったり。",
        "[ILBISONTE:カードケース]\n上質な牛革で有名のIL BISONTE。カラーが12種類あり、サイドにはストラップを掛けるリングがあるためデザインだけでなく機能面でも優れています。"]
    
    let label2Array: NSArray = [
        "¥13,200〜¥18,800",
        "¥6,000〜15,000",
        "¥7,700",
        "¥31,460",
        "¥3,000〜",
        "¥2,000〜",
        "¥4,400",
        "¥17,600",
        "¥7,700",
        "¥7,700"]
    let URLlink:[String] = [
        "https://www.tokyodisneyresort.jp/ticket/index.html",
        "https://www.jalan.net/kankou/g2_901/?screenId=OUW3801",
        "https://edwin-mall.jp/shop/g/gLT2984-102-02",
        "https://www.danielwellington.com/jp/dw-bundle-dw00501107-petite-melrose-28mm-rg-white-petite-ashfield-36mm-rg-black/",
        "https://hello-iroha.com/album_kitchen/cat_budget/over3000en/",
        "https://www.qoo10.jp/gmkt.inc/Mobile/Search/DynamicAd.aspx?keyword=IPHONE%E3%82%B1%E3%83%BC%E3%82%B9-%E3%83%88%E3%83%A0%E3%81%A8%E3%82%B8%E3%82%A7%E3%83%AA%E3%83%BC&jaehuid=2026322887&gclid=CjwKCAiAm7OMBhAQEiwArvGi3AjEZjk-ACm6o1pPqvDxTSD5Tv8_LEt9AT2B87XydYIzADBM-rlJShoCb4EQAvD_BwE&&__ar=Y",
        "https://www.agnesb.co.jp/f/dsg-2519749",
        "https://www.fdcp.co.jp/canal/jewelry/151424430001",
        "https://gs.abc-mart.net/shop/g/g4387860001013/",
        "https://www.ilbisonte.jp/shop/onlinestore/item/view/shop_product_id/1889"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.maxX)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

    
