//
//  TableViewJ30K.swift
//  GIFT1
//
//  Created by 久保田凌也 on 2021/12/07.
//

import UIKit
import SafariServices
 
class TableViewJ30K: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "d-30-k-1-1",
            "j-20-k-2-1","j-30-k-3-1",
            "d-20-k-10-1","j-30-k-5-1",
            "d-30-k-4-1","d-30-k-3-1",
            "j-30-k-8-1","d-30-k-6-1",
            "d-30-k-5-1"]
        
        let img1Array: NSArray = [
            "d-30-k-1-2",
            "j-20-k-2-2","j-30-k-3-2",
            "d-20-k-10-2","j-30-k-5-2",
            "d-30-k-4-2","d-30-k-3-2",
            "j-30-k-8-2","d-30-k-6-2",
            "d-30-k-5-2"]
        
        let img2Array: NSArray = [
            "d-30-k-1-3",
            "j-20-k-2-3","j-30-k-3-3",
            "d-20-k-10-3","j-30-k-5-3",
            "d-30-k-4-3","d-30-k-3-3",
            "j-30-k-8-3","d-30-k-6-3",
            "d-30-k-5-3"]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10"]
    let label1Array: NSArray = [
        "[温泉旅行]\n温泉大国日本の大きな特長が、その多彩なロケーションで秘湯と呼ばれるような場所で非日常感も味わえ日々の疲れを癒すことができます。",
                "[SOW EXPERIENCE:FOR2]\nさまざまなジャンルの体験が選べるFOR2（フォーツー）ギフト。REDはGREENよりも本格的なアクティビティや、食事などが充実しています。",
                "[花キューピット:ダズンローズの花束]\n12本のバラには、それぞれ「感謝、誠実、幸福、信頼、希望、愛情、情熱、真実、尊敬、栄光、努力、永遠」の意味が込められています。",
                "[メッセージギフト]\n相手の名前やお互いの名前から詩を作ることができます。人柄やエピソードなどを反映することもでき、特別な2人の思い出を形に残すことができます。",
                "[ROYALCOPENHAGEN:オーバルデニッシュ]\n毎日の食卓に重宝するオーバル ディッシュ。使いやすいサイズの楕円形のディッシュは、人数分揃えて銘々のメインプレートにしてもよいです。",
                "[Baccarant:クリスタ タンブラー 2022]\n歓びを⼼に刻むお祝いや記念に、⼤切な贈り物として多くの⽅に選ばれてきたバカラのタンブラー。タンブラーの底面には2022年の年号が刻まれています。",
                "[WEDGWOOD:ルネッサンス ゴールド マグ]\nウェッジウッド創業時のネオ・クラシカルスタイルを現代風にアレンジしたパターンです。連続するオーバル(楕円)模様は、繊細な装飾のジャスパー カメオがモチーフとなっています。",
                "[八角箸:絆]\n頭部から箸先まで限りなく正八角形にこだわっています。箸の頭部から箸先までストレートに削り出すことで持ち手は太く握りやすい形状です。",
                "[ふとんタナカ:じぶんまくら]\n首は起きている間、ほぼ休まず頭部の重さを支えている部分。首や肩の負担を軽減し呼吸のしやすさも確保するので、いびきをかきやすい方にもおすすめです。",
                "[SUNTORY:ウイスキー響]\n日本の四季、日本人の繊細な感性、日本の匠の技を結集したウイスキーをコンセプトにしており、ウイスキーづくりの歴史のなかで培ってきた多彩な原酒と匠の技でつくりあげられたこだわりの逸品です。"]
    
    let label2Array: NSArray = [
        "¥14,000〜",
        "¥22,550",
        "¥8,800",
        "¥12,650",
        "¥9,350",
        "¥14,300",
        "¥11,000",
        "¥11,000",
        "¥27,500〜",
        "¥5,000〜"]
    let URLlink:[String] = [
        "https://www.jalan.net/onsen/",
        "https://www.sowxp.co.jp/catalogs/539",
        "https://www.i879.com/products/catalog-detail/categoryId/yb00/productCd/512045/?grid=catalog_yb00_photo",
        "https://giftmall.co.jp/gift2IoAhr/?gsf_pcid=131318%3A0%3A0&gclid=Cj0KCQiAhf2MBhDNARIsAKXU5GTrwOo7GAsC3eAGImhkUhAikmvjCp5CaoIma5TXfhKRPYnRWr5_9Y0aAtd-EALw_wcB",
        "https://www.royalcopenhagen.jp/products/detail.php?product_id=533",
        "https://www.baccarat.jp/ja/%E3%83%90%E3%83%BC%E3%82%A6%E3%82%A7%E3%82%A2/%E3%83%8F%E3%82%A4%E3%83%9C%E3%83%BC%E3%83%AB%E3%80%81%E3%82%BF%E3%83%B3%E3%83%96%E3%83%A9%E3%83%BC/%E3%82%AF%E3%83%AA%E3%82%B9%E3%82%BF-%E3%82%BF%E3%83%B3%E3%83%96%E3%83%A9%E3%83%BC-2022-2814889.html#start=1",
        "https://www.wedgwood.jp/products/detail/533374",
        "https://www.hashikura1922.com/smartphone/detail.html?id=000000000833&gclid=CjwKCAiAhreNBhAYEiwAFGGKPPkfRIYLJpzNJcbNZd5jGO2KIoETWg4FhExJpmp7uhNA2cpvvEufABoCLVgQAvD_BwE",
        "https://jibunmakura.com/jibunmakura/",
        "https://www.suntory.co.jp/whisky/products/0000000038/0000000114.html"]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


