//
//  ViewController.swift
//  GIFT
//
//  Created by 二宮大智 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TableViewJ30T: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "j-30-t-1-1",
            "j-30-t-2-1","j-30-t-3-1",
            "j-30-t-4-1","d-20-k-7-1",
            "j-30-t-6-1","j-30-t-7-1",
            "j-30-t-8-1","j-30-t-9-1",
            "j-30-t-10-1"
]
        
        let img1Array: NSArray = [
            "j-30-t-1-2",
            "j-30-t-2-2","j-30-t-3-2",
            "j-30-t-4-2","d-20-k-7-2",
            "j-30-t-6-2","j-30-t-7-2",
            "j-30-t-8-2","j-30-t-9-2",
            "j-30-t-10-2",]
        
        let img2Array: NSArray = [
            "j-30-t-1-3",
            "j-30-t-2-3","j-30-t-3-3",
            "j-30-t-4-3","d-20-k-7-3",
            "j-30-t-6-3","j-30-t-7-3",
            "j-30-t-8-3",
            "j-30-t-9-3","j-30-t-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[YAMAN:フォトスチーマー]\n左右2つの吹出口から放出されるたっぷりの温スチームが、顔全体を包み込みます。細かい粒子のスチームが肌温度を約40℃まで引き上げ、角質層をやわらげ、スキンケアの土台作りを行います。",
            "[T-fal:IHルージュセット9]\nティファール史上最高峰のこびりつきにくさと耐久性で高級感のある人気の定番カラーです。さらにラインナップも豊富となっております。",
            "[Daito:マッサージャー MD-8671]\n椅子やソファでの使用はもちろん、床において寝ながらの使用が可能で自動コースは全4種類、従来の全身・肩・腰に加え、寝て使用時に特に気持ちいい「ストレッチコース」もあります。",
            "[dyson:Airwa Complete]\nエアリーカールも、ブローも、ドライも1台で。過度な熱ダメージを防ぎ、濡れた髪から風でスタイリングできます。",
            "[TWINBIRD:CM-D457B]\nコーヒー界のレジェンド田中護氏監修のもと豆の風味を損なわないフラットミルとシャワードリップでプロのハンドドリップを再現しています。",
            "[MICHA MICHAEL KORS:トップジップ トート]\nシボ感が美しいクロスグレインレザーを使用したVOYAGER ミディアム トップジップ トート。内部にはジップポケットや複数のスリップポケットを備えています。",
            "[TANP:フェイスタオル]\nふわふわもちもちの触りごごちをいつでも楽しめるフェイスタオルのギフトセットが登場しました。タオルは吸水力抜群ですが早く乾き、何度も顔を埋めたくなる柔らかい肌触りです。",
            "[SK-2:フェイシャル トリートメント マスク]\nピテラをたっぷり配合。50種類以上のビタミン類、ミネラル類、アミノ酸類、有機酸類を含んでいます。",
            "[CHANEL:ルージュ ココ ブルーム セット]\n圧倒的な輝きと発色のプランプリップ、マストアイテムがポーチに入った特別限定セット。シルバーとブラックのパッケージのトップからは鮮やかなリップスティックの色が覗きます。",
            "[Giftmall:ワイン]\n新潟で作られたワインのラベルに文字を彫ることができ、さらに生まれ年の新聞もついてくるので思い出も遡ることができます。",
            ]
        
        let label2Array: NSArray = [
            "¥79,200",
            "¥28,050",
            "¥43,780",
            "¥44,000",
            "¥43,070",
            "¥51,700",
            "¥6,930",
            "¥11,000",
            "¥18,480",
            "¥19,000",
            ]
    let URLlink: [String] = [
    "https://www.ya-man.com/products/photo-steamer/lp/?oadid=a_1_s_aa_db_ga_jm_nb_pa_a01_9999&utm_source=google&utm_medium=display&utm_campaign=a01_nb&utm_content=pla9999&gclid=CjwKCAiAhreNBhAYEiwAFGGKPHJydvN1IS50waHoOPqb5JKtKAjThmMph4ByaboSkkXwaetG92FrIBoCflEQAvD_BwE",
    "https://www.t-fal-onlineshop.jp/tfal/shop/goods/index.html?ggcd=2100121073&cid=ck_stackable01_13",
    "https://daito-thrive.co.jp/store/products/detail.php?product_id=450",
    "https://www.dyson.co.jp/shop/hair-care.aspx?mkwid=s_dm&pcrid=501967287106&pkw=%E3%83%80%E3%82%A4%E3%82%BD%E3%83%B3%20%E3%83%89%E3%83%A9%E3%82%A4%E3%83%A4%E3%83%BC&pmt=e&utm_source=google&utm_term=%E3%83%80%E3%82%A4%E3%82%BD%E3%83%B3%20%E3%83%89%E3%83%A9%E3%82%A4%E3%83%A4%E3%83%BC&utm_medium=&utm_campaign=&utm_content=&ds_rl=1256890&gclid=CjwKCAiAhreNBhAYEiwAFGGKPKi_Ze7rCdRnA7SDCbFNsapp_Ic2iVUqlPu5RCNSUIrVf3CA_rOMvBoCbmwQAvD_BwE&gclsrc=aw.ds#Hair-dryers?",
    "https://store.twinbird.jp/products/cmd457",
    "https://www.michaelkors.jp/products/detail.php?product_id=1760",
    "https://tanp.jp/products/view/2373",
    "https://www.sk-ii.jp/product/facial-treatment-mask?gclid=CjwKCAiAhreNBhAYEiwAFGGKPFIxJXqPKN_3PDLpCieKGdMjI0JJpE166Kz5tTL8EbCxNFI4Ios-xRoCaCIQAvD_BwE&gclsrc=aw.ds",
    "https://www.chanel.com/jp/makeup/p/100535/essential-lips-and-face-set-rouge-coco-bloom-rouge-coco-baume-and-le-blanc-whitening-compact-foundation/",
    "https://giftmall.co.jp/giftaG2kXs/"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}
