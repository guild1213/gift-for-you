//
//  TableViewJ30C.swift
//  GIFT
//
//  Created by 朝倉健登 on 2021/12/07.
//
import UIKit
import SafariServices
 
class TableViewJ30C: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "j-30-c-1-1",
            "j-30-c-2-1","j-30-c-3-1",
            "j-30-c-4-1","j-30-c-5-1",
            "j-30-c-6-1","j-30-c-7-1",
            "j-30-c-8-1","j-30-c-9-1"
            ,"j-30-c-10-1"
]
        
        let img1Array: NSArray = [
            "j-30-c-1-2",
            "j-30-c-2-2","j-30-c-3-2",
            "j-30-c-4-2","j-30-c-5-2",
            "j-30-c-6-2","j-30-c-7-2",
            "j-30-c-8-2","j-30-c-9-2",
            "j-30-c-10-2",]
        
        let img2Array: NSArray = [
            "j-30-c-1-3",
            "j-30-c-2-3","j-30-c-3-3",
            "j-30-c-4-3","j-30-c-5-3",
            "j-30-c-6-3","j-30-c-7-3",
            "j-30-c-8-3",
            "j-30-c-9-3","j-30-c-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[agete:K18ネックレス]\nテーパーバゲットカットダイヤモンド2石を、石の選定と石留めの技術によって、1石のダイヤモンドのように見えるデザインになっています。",
                        "[LOEWE:バイカラー スカーフ]\nツートーンスカーフ。フリンジエンド、コントラストアナグラム刺繍入り。ピンクが差し色になっていてどのコーデにも合います。",
                        "[ReFa CARAT:リファカラットフェイス]\n女性の顔・デコルテ専用に設計されたしなやかに手になじむコンパクトなローラーです。ダブルドレナージュローラーにより、プロの手技「ニーディング」の複雑で高度な動きを再現しています。",
                        "[Francfranc:シレーヌ]\n5リットルの大容量タンクで長時間うるおしてくれる2WAY超音波式加湿器です。タンクが大容量なので面倒な水汲みの手間が軽減できます。",
                        
                        "[TIFFANY&Co.:ブレスレット]\n光を浴びたティファニー ダイヤモンドが、揺れるような美しいきらめきを放ちます。ラウンド ブリリアント カットのダイヤモンドをあしらったスターリングシルバーのブレスレットです。",
                        "[Anny:アルティメットウェルビーニング]\nアロマセラピー アソシエイツのバスアンドシャワーオイルが10種類すべてお楽しみいただけるセットです。",
                        "[EARLYBIRD:ハンドミスト]\nナノテクノロジーによる微粒子をわずか10秒で肌へ届ける携帯ミスト『PureNano』シリーズ。目に見えるツヤ、透明感とともに一瞬で感じる心地よさです。",
                        " [JILLSTART:ハンドクリーム]\nホワイトフローラル、ロージーズ、ブルーミングペアー3種の香りが楽しめるハンドクリームセットです。",
            "[DIOR:アドヴェントカレンダー]\nクリスマスまでの特別な24日間をディオールのフレグランス・メイクアップ・スキンケア アイテムとカウントダウンする特別なアドヴェント カレンダーです。",
                        "[FURLA:コスメケース]テクスチャードレザー製のフルラ エレクトラ コスメティックケース。機能的で容量が大きく、フロントにはメタルの小さなフルラロゴをあしらっています。",
                    
            ]
   
        let label2Array: NSArray = [
            "¥44,000",
            "¥44,000",
            "¥9,900",
            "¥9,800",
            "¥47,300",
            "¥14,630",
            "¥9,350",
            "¥4,510",
            "¥73,150",
            "¥13,200"]
    let URLlink: [String] = [
                "https://agete.com/item/detail/1_1_10214127014_08_1/08",
                "https://www.loewe.com/jap/ja/%E3%82%A6%E3%82%A3%E3%83%A1%E3%83%B3%E3%82%BA/%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B5%E3%83%AA%E3%83%BC/%E3%82%B9%E3%82%AB%E3%83%BC%E3%83%95%EF%BC%86%E3%82%B7%E3%83%A7%E3%83%BC%E3%83%AB/%E3%83%90%E3%82%A4%E3%82%AB%E3%83%A9%E3%83%BC-%E3%82%B9%E3%82%AB%E3%83%BC%E3%83%95-(%E3%82%A6%E3%83%BC%E3%83%ABand%E3%82%AB%E3%82%B7%E3%83%9F%E3%83%A4)/F810250X01-7254.html?country=JP&lang=ja&gclid=CjwKCAiAhreNBhAYEiwAFGGKPNTNh7irETfVfRCoAs_0uuVHzHEpUUvCMp4ZZkr86Jadiz-ZOnaJFhoCJd0QAvD_BwE",
                "https://www.mtgec.jp/shop/g/g9234901001/",
                "https://francfranc.com/products/1109070006888?variant=31714880094231",
                "https://www.tiffany.co.jp/jewelry/bracelets/elsa-peretti-diamonds-by-the-yard-bracelet-33943415/",
                "https://anny.gift/products/4096/?gclid=CjwKCAiAhreNBhAYEiwAFGGKPB4rNVvSEt6UvXZrCucUn1m7Glzwpn9BzSnQfQL9p1pJ9QkZhSqFnhoCFCMQAvD_BwE",
                "https://eb-online.jp/products/purenano?variant=30868191412333&currency=JPY&utm_medium=product_sync&utm_source=google&utm_content=sag_organic&utm_campaign=sag_organic&utm_term=&utm_campaign=%E3%82%B7%E3%83%A7%E3%83%83%E3%83%94%E3%83%B3%E3%82%B0%E5%BA%83%E5%91%8A&utm_source=adwords&utm_medium=ppc&hsa_acc=8874024077&hsa_cam=10618487012&hsa_grp=102178597862&hsa_ad=450584862712&hsa_src=g&hsa_tgt=pla-294682000766&hsa_kw=&hsa_mt=&hsa_net=adwords&hsa_ver=3&gclid=CjwKCAiAhreNBhAYEiwAFGGKPOKBUPnS_hfywHbTYJB3yDp5PcvMgps_qMl3N0GAp79oTWQNvhSQcxoCaVAQAvD_BwE",
                "https://www.jillstuart-floranotisjillstuart.com/site/jillstuart/g/gJLS0278/",
                "https://www.dior.com/ja_jp/products/beauty-Y0996351-%E3%83%87%E3%82%A3%E3%82%AA%E3%83%BC%E3%83%AB-%E3%82%A2%E3%83%89%E3%83%B4%E3%82%A7%E3%83%B3%E3%83%88-%E3%82%AB%E3%83%AC%E3%83%B3%E3%83%80%E3%83%BC-%E4%B8%80%E9%83%A8%E5%BA%97%E8%88%97%E6%95%B0%E9%87%8F%E9%99%90%E5%AE%9A%E5%93%81-%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9%E3%81%BE%E3%81%A7%E3%81%AE%E7%89%B9%E5%88%A5%E3%81%AA24%E6%97%A5%E9%96%93%E3%82%92%E3%83%87%E3%82%A3%E3%82%AA%E3%83%BC%E3%83%AB%E3%81%AE%E3%83%95%E3%83%AC%E3%82%B0%E3%83%A9%E3%83%B3%E3%82%B9%E3%83%BB%E3%83%A1%E3%82%A4%E3%82%AF%E3%82%A2%E3%83%83%E3%83%97%E3%83%BB%E3%82%B9%E3%82%AD%E3%83%B3%E3%82%B1%E3%82%A2-%E3%82%A2%E3%82%A4%E3%83%86%E3%83%A0%E3%81%A8%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E3%83%80%E3%82%A6%E3%83%B3%E3%81%99%E3%82%8B%E7%89%B9%E5%88%A5%E3%81%AA%E3%82%A2%E3%83%89%E3%83%B4%E3%82%A7%E3%83%B3%E3%83%88-%E3%82%AB%E3%83%AC%E3%83%B3%E3%83%80%E3%83%BC?objectID=Y0996351&query=%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%9E%E3%82%B9&queryID=e572c8f0d44bb9c88edee400ca30ac96",
                "https://www.furla.com/jp/ja/eshop/furla-electra-EAW2LN1B300001007MIM00.html"]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}

