//
//  ViewController.swift
//  GIFT
//
//  Created by 二宮大智 on 2021/12/06.
//

import UIKit
import SafariServices
 
class TableViewJ30C: UIViewController ,
UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var table:UITableView!
    
    // section毎の画像配列
    let imgArray: NSArray = [
            "j-20-t-1-1",
            "j-20-t-2-1","j-20-t-3-1",
            "j-20-t-4-1","j-20-t-5-1",
            "j-20-t-6-1","j-20-t-7-1",
            "j-20-t-8-1","j-20-t-9-1",
            "j-20-t-10-1"
]
        
        let img1Array: NSArray = [
            "j-20-t-1-2",
            "j-20-t-2-2","j-20-t-3-2",
            "j-20-t-4-2","j-20-t-5-2",
            "j-20-t-6-2","j-20-t-7-2",
            "j-20-t-8-2","j-20-t-9-2",
            "j-20-t-10-2",]
        
        let img2Array: NSArray = [
            "j-20-t-1-3",
            "j-20-t-2-3","j-20-t-3-3",
            "j-20-t-4-3","j-20-t-5-3",
            "j-20-t-6-3","j-20-t-7-3",
            "j-20-t-8-3",
            "j-20-t-9-3","j-20-t-10-3",]
        let img3Array: NSArray = [
            "R1",
            "R2","R3",
            "R4","R5",
            "R6","R7",
            "R8","R9",
            "R10",]
        let label1Array: NSArray = [
            "[Kate spade:コンチネンタルウォレット]\nスペードフラワーコレクションにシーズン問わずモテるPVC加工を施したシリーズが新たに誕生。まるで絵画ののように並んだスペードフラワーパターンを採用した品です。",
            "[Marc Jacobs:Roxy MJ1532]\nマークジェイコブスのシグネチャースタイルとも言えるロキシーコレクション。ホワイトとゴールドの文字盤ケースにブラックレザーベルトが定番のスタイルに見事にはまります。",
            "[COACH:ショルダーバッグ]\nバターのように柔らかくしっとりとしたグラブタン レザーのミニ バッグ。身軽に持てるコンパクトサイズながら、長財布まで収納可能できる仕切りのないゆったりとした空間。",
            "[CHANEL:ホリデー メークアップ セット]\nホリデー シーズンに贈る、大切な人へのギフトにも、ご自身へのご褒美にも最適なオンライン ブティック限定セット。鮮やかな発色、つや、うるおいが長時間続く、色移りしにくいです。",
            "LANCOME:エッセンスローション]\n酵素を手がかりに。新次元の透明肌へ。二層エッセンスが潤いとみずみずしさを解き放ち肌に備わる酵素で生まれ変わりをサポートするなどの役割を持ちます。",
            "[TIFFANY&Co:オリーブ リーフ バンド リング]\nスターリングシルバーのナロー バンドリングでパロマは平和と栄光の象徴であるオリーブの枝を称え、美しい葉をスターリングシルバーでかたどりました。",
            "[ete:K18 ダイヤモンド ネックレス]\nダイヤモンドをより美しく輝かせることに、こだわり抜いたコレクションです。ダイヤモンドの花が咲いたような愛らしさがありながら、シンプルで洗練された佇まいになっています。",
            "[Who’sWho’sChico:サイドゴアボリュームショートブーツ]\n今年気分の重量感のあるブーツでミニ丈やハーフ丈のボトムスとの相性がよくヒールは高すぎないので楽チンにスタイルアップが出来ます。",
            "[@aroma:ホリデーギフト 2021]\nストレスや日々の暮らし、今の自分から心も身体も解き放たれるよう、バニラやネロリをはじめとする贅沢な香りをふんだんにブレンドしました。",
            "[VivienneWestwood:コスメティックポーチ]\n 型崩れしにくい丈夫なサフィアーノレザーを使用したシンプルなポーチ。エナメルカラーが美しいDIAMANTE HEARTがアクセントに。",
            ]
        
        let label2Array: NSArray = [
            "¥34,100",
            "¥34,800",
            "¥11,000",
            "¥70,400",
            "¥15,620",
            "¥12,100",
            "¥33,550",
            "¥8,250",
            "¥3,740",
            "¥33,000",
            ]
    let URLlink: [String] = [
    "https://www.katespade.jp/wallets/wallets-category/continentalwallets/PWR00085.html?c_cgid=continentalwallets",
    "https://www.world-marc-shop.com/?pid=114140139",
    "https://japan.coach.com/goods/C6641?color=B4HA&DISP_NO=005002002005&positionId=127837",
    "https://www.chanel.com/jp/makeup/p/100559/rouge-allure-laque-ultrawear-shine-liquid-lip-colour-set/",
    "skincare/by-product-category/toners/clarifique-dual-essence-lotion/A01819-LAC.html#start=8&cgid=L3_Axe_Skincare_The_Toners",
    "https://www.tiffany.co.jp/jewelry/rings/paloma-picasso-olive-leaf-band-ring-GRP06620/",
    "https://www.eteweb-shop.com/items/260838-660838",
    "https://www.palcloset.jp/display/item/CHZ1012113A0002/?b=chico",
    "https://store.at-aroma.com/item/CAT_OIL_XMAS_2021_5BLENDS.html",
    "https://www.viviennewestwood-tokyo.com/f/dsg-2327183"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    //Table Viewのセルの数を指定
    func tableView(_ table: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return imgArray.count
    }
    
    //各セルの要素を設定する
    func tableView(_ table: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // tableCell の ID で UITableViewCell のインスタンスを生成
        let cell = table.dequeueReusableCell(withIdentifier: "tableCell",
                                             for: indexPath) as! TableViewCell
        
        let img3 = UIImage(named: img3Array[indexPath.row] as! String)
        
        let img = UIImage(named: imgArray[indexPath.row] as! String)
        
        let img1 = UIImage(named: img1Array[indexPath.row] as! String)
        
        let img2 = UIImage(named: img2Array[indexPath.row] as! String)
        
        
        // Tag番号 1 ランキング画像
        let imageView3 = cell.viewWithTag(100) as! UIImageView
        imageView3.image = img3
        // Tag番号 2 画像1枚目
        let imageView = cell.viewWithTag(200) as! UIImageView
        imageView.image = img
        // Tag番号 3 画像2枚目
        let imageView1 = cell.viewWithTag(300) as! UIImageView
        imageView1.image = img1
        // Tag番号 4 画像3枚目
        let imageView2 = cell.viewWithTag(400) as! UIImageView
        imageView2.image = img2
        
        // Tag番号 5 商品名：商品紹介
        let label1 = cell.viewWithTag(600) as! UILabel
        label1.text = String(describing: label1Array[indexPath.row])
        
        
        // Tag番号 6 商品値段
        let label2 = cell.viewWithTag(500) as! UILabel
        label2.text = String(describing: label2Array[indexPath.row])
        
        
        // Tag番号 7 商品URL
        cell.button.tag = indexPath.row
        cell.scroll.tag = indexPath.row + 20
        cell.scroll.delegate = self
        cell.page.tag = indexPath.row + 40
//        url = URL(string: abc[indexPath.row])
        cell.button.addTarget(self, action: #selector(touchbutton), for: .touchUpInside)
        
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        var indexpath = IndexPath()
        if scrollView.tag > 0{
        switch scrollView.tag {
        case 20:
            indexpath = IndexPath(row: 0, section: 0)
        case 21:
            indexpath = IndexPath(row: 1, section: 0)
        case 22:
            indexpath = IndexPath(row: 2, section: 0)
        case 23:
            indexpath = IndexPath(row: 3, section: 0)
        case 24:
            indexpath = IndexPath(row: 4, section: 0)
        case 25:
            indexpath = IndexPath(row: 5, section: 0)
        case 26:
            indexpath = IndexPath(row: 6, section: 0)
        case 27:
            indexpath = IndexPath(row: 7, section: 0)
        case 28:
            indexpath = IndexPath(row: 8, section: 0)
        case 29:
            indexpath = IndexPath(row: 9, section: 0)
        case 30:
            indexpath = IndexPath(row: 10, section: 0)
        default:
            break
        }
        let cell = table.cellForRow(at: indexpath) as! TableViewCell
        cell.page.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.width)
        }
    }
    var url = URL(string:"")
    @objc func touchbutton(_ sender: UIButton){
        url = URL(string: URLlink[sender.tag])
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!)
        }
    }

    // Cell の高さを１２０にする
    func tableView(_ table: UITableView,
                   heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
}
